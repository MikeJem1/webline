from django.contrib import admin
from .models import user, Poste
# Register your models here.
@admin.register(user)
class UserAdmin(admin.ModelAdmin):
    list_display=('id','name','password','email','titre','image')

@admin.register(Poste)
class PostAdmin(admin.ModelAdmin):
    list_display=('id','titre')