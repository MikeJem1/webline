from django.db import models

# Create your models here.

class user(models.Model):
    name=models.CharField(max_length=70)
    email=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    image = models.ImageField(upload_to='media/',null=True, blank=True)
    titre=models.CharField(max_length=100, default='')
    def __str__(self):
        if self.titre:
            return self.titre
        else:
            return f"User {self.id}"


class Poste(models.Model):
    titre= models.CharField(max_length=100)
    content =models.TextField()
    image = models.ImageField(upload_to='media/',null=True, blank=True)
    def __str__(self):
        return self.titre