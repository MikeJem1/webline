from django.urls import path
from . import views

urlpatterns =[
    path('premye',views.FirstPage),
    path('index',views.secondpage),
    path('login/',views.user_login, name='login')

]