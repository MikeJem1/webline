from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .forms import studentRegistration
from .models import user
from django.contrib.auth import authenticate, login
# Create your views her
def FirstPage(request):
    return render(request,'index.html')

def secondpage(request):
    if request.method=='POST':
        form=studentRegistration(request.POST)
        if form.is_valid():
            nm= form.cleaned_data['name']
            em= form.cleaned_data['email']
            pw= form.cleaned_data['password']
            reg= user(name = nm, email = em, password= pw)
            reg.save()
            form = studentRegistration
           # return redirect('FirtsPage')
    else:
       form=studentRegistration()
    return render(request,'registrer.html',{'form':form})


def user_login(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        user=authenticate(request, email=email, password=password)
        if user is not None:
            login(request,user)
            return redirect('FirstPage')
        else:
          messages.error(request, "Désolé, impossible de vous connecter avec ces informations. Veuillez vérifier votre email et votre mot de passe.")
        
    return render(request,'login.html')
